"""
Tests for python-lin package
"""