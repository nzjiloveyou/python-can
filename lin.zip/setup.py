"""
Setup script for python-lin package
"""
from setuptools import setup

# setup.cfg is the primary configuration source
# This file exists for compatibility with older tools
setup()